<template>
    <div class="dashboard">
        <Sidebar />
        <div class="content">
            <router-view />
        </div>
    </div>
</template>

<script>
import Sidebar from "../components/Sidebar.vue";

export default {
    name: "Home",

    components: {
        Sidebar,
    },
};
</script>

<style scoped>
.dashboard {
    display: grid;
    grid-template-columns: 1fr 5fr;
    background-color: #212936;
    height: 100vh;
    width: 100vw;
}

.content {
    background-color: #2b3648;
}
</style>
