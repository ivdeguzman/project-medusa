<template>
    <div class="MainMenu">
        <p>Main Menu</p>
    </div>
    
</template>

<script>
export default {
    
}
</script>

<style scoped>
    .MainMenu{
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
        width: 100%;
        font-size: 30px;
        color: gray;
    }
</style>
