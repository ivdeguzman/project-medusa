<template>
    <div class="Sections">
        <p>Sections</p>
    </div>
    
</template>

<script>
export default {
    
}
</script>

<style scoped>
    .Sections{
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
        width: 100%;
        font-size: 30px;
        color: gray;
    }
</style>
