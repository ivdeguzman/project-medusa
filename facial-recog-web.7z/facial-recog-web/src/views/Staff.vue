<template>
    <div class="Staff">
        <p>Staff</p>
    </div>
</template>

<script>
export default {};
</script>

<style scoped>
.Staff {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    width: 100%;
    font-size: 30px;
    color: gray;
}
</style>
